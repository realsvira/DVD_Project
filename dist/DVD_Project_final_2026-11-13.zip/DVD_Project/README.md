# ML-Driven PVT Variation Aware Leakage Estimation

Digital VLSI Design course project. The specification is `DVD_ML_PROJECT.pdf`, which is the primary reference.

**Team:** Saumya Vira, Anish Toshniwal, Shrenil Patel, Het Selarka.

**What this project does:**
- **Part A:** learns the four terminal currents (Id, Ig, Is, Ib) of single transistors (NMOS/PMOS, ON/OFF) from 40,000+ ngspice simulations under PVT variation.
- **Part B:** predicts the leakage of INV, NAND2, NOR2, AND2 and OR2 hierarchically from those transistor models (18 gate/input cases × 200 PVT corners).
- **Part C:** composes the gate models into the assigned **3-bit carry-lookahead adder** (36 gates, 192 transistors) and validates each level against SPICE.

| Item | Team value |
|---|---|
| Model file | **45nm HP**: PTM 45 nm high performance, metal gate / high-k (`models/45nm_HP.pm`) |
| Nominal VDD | **1.0 V** (sampled 0.9–1.1 V) |
| Channel length / widths | L = 45 nm; W = 45–360 nm |
| Test circuit | **3-bit carry-lookahead adder** (Cin = 0, 64 vectors) |
| Simulator / language | ngspice 44.2 (`ngspice_con.exe`) / Python 3.13.14, Windows 11 |

## Final results (final models, independent evaluation data)

| Level | Median error | 95th-percentile error | Mean accuracy* |
|---|---|---|---|
| Transistor (fresh test, spec distribution, 4 cases × 4 terminals) | 0.61 % | 3.4 % | 98.56 % |
| Gates (18 cases × 200 **new** PVT corners) | 0.78 % | 3.0 % | 98.93 % |
| 3-bit CLA (64 vectors × 200 **new** PVT corners) | 0.57 % | 2.3 % | **99.24 %** |

\*Mean accuracy = 100 % · (1 − mean |ML − SPICE| / SPICE).
- **99 % target:** reached at circuit level; **not** reached at gate (98.9 %) or transistor (98.6 %) level.
- **Official Part B/C corners:** gates 98.97 %, CLA 99.30 %.
- **Full report:** [`reports/FINAL_REPORT.md`](reports/FINAL_REPORT.md), with a self-contained HTML copy at `reports/FINAL_REPORT.html` that can be printed to PDF from a browser.
- **Requirement → file map:** [`reports/deliverables_checklist.md`](reports/deliverables_checklist.md).

## Quick start (Windows PowerShell, from the project root)

**New to Python, Git or SPICE?** Follow [`docs/BEGINNER_GUIDE.md`](docs/BEGINNER_GUIDE.md) step by step. The full installation guide is [`docs/INSTALL_WINDOWS.md`](docs/INSTALL_WINDOWS.md).
```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
$env:NGSPICE = "C:\Spice64\bin\ngspice_con.exe"          # wherever ngspice_con.exe is
.\.venv\Scripts\python.exe run_all.py --mode verify        # env check + 90 tests + deliverable audit (~1 min)
.\.venv\Scripts\python.exe run_all.py --mode smoke         # small end-to-end run of every stage (~3 min)
.\.venv\Scripts\python.exe run_all.py --list               # all stages; --mode full regenerates everything
```
Predict one transistor with the final models (and compare with ngspice):
```powershell
.\.venv\Scripts\python.exe scripts\a2_predict.py --device nmos --vd 1.0 --vg 0 --vs 0 --vb 0 --vdd 1.0 --temp 27 --w 90e-9 --spice
```

## Stage order (`run_all.py --mode full`)

| # | Stage | Script(s) | Main outputs |
|---|---|---|---|
| 0 | environment, inputs | `check_environment.py`, `inventory_inputs.py` | `reports/environment_check.txt`, `reports/input_inventory.md` |
| A1 | engine, datasets, data check | `a1_smoke_test.py`, `a1_generate_datasets.py`, `a1_data_check.py` | `netlists/transistor/`, `data/transistor/`, `results/data_check/` |
| A2 | 4 model types × 4 cases | `a2_train_models.py`, `a2_evaluate_test.py` (one-time) | `results/a2/`, model history |
| A2b | v2 (signed-log Vds, targeted data) | `a2b_train_v2.py`, `a2b_evaluate_test2.py` (one-time) | `results/a2b/` |
| B3 | gate SPICE references | `b3_gate_spice.py` | `netlists/gates/`, `data/gates/` |
| B4–5 | hierarchical gate ML | `b4_gate_ml.py` | `results/b4/` (models of that stage) |
| C | CLA3 SPICE + hierarchical ML | `c1_cla_spice.py`, `c2_cla_ml.py` | `netlists/circuit/`, `data/circuit/`, `results/c/` |
| D | improvement phase | `d1`–`d5` scripts | `results/improve/`, `trained_models/v3/` |
| Z | final deliverables, report, audit | `z1_final_deliverables.py`, `z3_build_report.py`, `z2_audit.py` | `results/final/`, `reports/` |

Seeds are fixed in `config/project.toml` (`[seeds]`). Generation stages are resumable, training stages cache every fit, and the one-time evaluations refuse to run twice.

## Project layout

```
config/project.toml        central configuration: assignment, ranges, seeds, paths, ngspice
src/leakage/               package: config, spice, simulator, transistor, dataset, ml, torch_mlp,
                           inference, gates, gate_ml, circuit
scripts/                   one script per stage (see table above); run_all.py at the root runs them
tests/                     pytest suite (90 tests)
netlists/                  example netlists: transistor (4), gates (5), circuit (CLA3)
data/                      datasets and SPICE references (transistor, aug, gates, circuit, final_eval)
trained_models/            final models (*.joblib = v3) + v1/, v2/, v3/, final_before_improvement/
results/                   per-stage tables and figures; results/final = final-model deliverables
reports/                   FINAL_REPORT.md/.html, deliverables_checklist.md, stage reports, figures/
docs/                      INSTALL_WINDOWS.md (installation), BEGINNER_GUIDE.md (step by step from zero)
models/, model/, *.pdf, *.zip, 22n_NMOS_ON.net   supplied inputs (unchanged)
```
`models/*.pm` are SPICE model cards (BSIM4), not ML models. The ML models are in `trained_models/`.

---

# Stage details

The sections below document each stage as it was carried out. Numbers quoted inside a stage refer to the models of that stage (v1, v2 and so on); the final numbers are in the table at the top.

## Setup (Windows)

### 1. Check Python
PowerShell:
```powershell
python --version
```
You need 3.11 or newer.

### 2. Find ngspice
`ngspice -v` gives "not recognized" because ngspice is not on PATH. On this machine it is at:
```
D:\VLSI\NGSPICE\ngspice-44.2_64\Spice64\bin\ngspice_con.exe
```
Use **`ngspice_con.exe`** in a terminal. `ngspice.exe` is the GUI build and opens its own window.

To locate it on another machine:
```powershell
Get-ChildItem C:\,D:\ -Recurse -Filter ngspice_con.exe -ErrorAction SilentlyContinue | Select-Object -First 5 FullName
```
To verify it:
```powershell
& "D:\VLSI\NGSPICE\ngspice-44.2_64\Spice64\bin\ngspice_con.exe" -v
```

The project does **not** need ngspice on PATH. It looks in this order:
1. the `NGSPICE` environment variable,
2. `[ngspice].path` in `config/project.toml`,
3. `ngspice_con` / `ngspice` on PATH,
4. common install folders (`C:\Spice64\bin`, ...).

Teammates with a different install location can set the path for one session:
```powershell
$env:NGSPICE = "C:\Spice64\bin\ngspice_con.exe"
```
Optional: to add it permanently to your **user** PATH (open a new terminal afterwards):
```powershell
[Environment]::SetEnvironmentVariable("Path", [Environment]::GetEnvironmentVariable("Path","User") + ";C:\Spice64\bin", "User")   # the folder that contains ngspice_con.exe
```

### 3. Create the virtual environment and install dependencies
From the project root (the `DVD_Project` folder):
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```
If activation is blocked by the execution policy, run this once:
```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```
Alternatively, skip activation and call `.\.venv\Scripts\python.exe` directly.

CMD equivalent:
```bat
python -m venv .venv
.venv\Scripts\activate.bat
pip install -r requirements.txt
```

Or do all of setup in one step:
```powershell
powershell -ExecutionPolicy Bypass -File scripts\setup_env.ps1
```

### 4. Verify
```powershell
.\.venv\Scripts\python.exe scripts\inventory_inputs.py
.\.venv\Scripts\python.exe scripts\check_environment.py
.\.venv\Scripts\python.exe -m pytest -q tests
```
Setup succeeded when:
* `check_environment.py` ends with **`ENVIRONMENT OK`** and exits with code 0 (every line is `[PASS]`), and
* pytest reports all tests passed.

`check_environment.py` confirms that:
- Python is new enough and all packages import;
- the config loads;
- `models/45nm_HP.pm` exists and its SHA-256 matches the config;
- both model cards are BSIM4 (level 54) and the nominal vth0/toxe/ndep/u0/xj values parse;
- ngspice is found and answers `-v`;
- Python can run an ngspice batch simulation of NMOS OFF and PMOS OFF using the required `.options`;
- the simulator loaded exactly the file's parameter values (via `showmod`);
- the four terminal currents of each device sum to ~0 (Kirchhoff's current law);
- editing a model card (toxe −10 %) raises gate leakage as expected.

Results are also written to `reports/environment_check.txt`.

---

## Conventions and design decisions

* **Current sign:** every terminal current is positive when it flows **into** the device.
  ngspice reports `i(Vx)` flowing + to − through the source, so I_terminal = −i(Vx).
* **Units (SI, as in the BSIM4 cards):** W, L, toxe, xj in m; vth0 in V; ndep in cm⁻³;
  u0 in m²/(V·s); temperature in °C; currents in A.
* **Process variation is written into a fresh model card per sample.**
  Do not use `altermod` for `toxe`. ngspice 44.2 accepts the new value but does not recompute the
  oxide-derived terms, so gate and channel currents come out wrong by up to ~5×. This was measured
  in this project against fresh netlists. vth0, ndep, u0 and xj behaved correctly under `altermod`,
  but the project uses one trusted code path for all five parameters.
* **Only `toxe` is varied.** toxp, toxm and toxref keep their nominal values, as the spec lists only toxe.
* **Model copy:** `models/45nm_HP.pm` (from `Model Files-20261112.zip`). The older copies in `model/`
  and `model.tar` differ only in whitespace. See `reports/input_inventory.md`.
* **Simulator note:** ngspice reports the `version = 4.0` BSIM4 cards as "BSIM4v5". The printed
  "No compatibility mode selected!" is informational only.
* **Reproducibility:** all random seeds live in `config/project.toml` under `[seeds]`.

## Part A1: transistor simulation engine

### Modules
| File | Role |
|---|---|
| `src/leakage/simulator.py` | `NgspiceSimulator.run_op(circuits, vectors)`. A general batch DC operating-point engine, reused later for gates and the CLA. |
| `src/leakage/transistor.py` | Single-FET netlist generator and API: `make_inputs`, `sample_inputs`, `transistor_circuit`, `example_netlist`, `simulate_transistors`, `simulate_transistor`, `kcl_residual`, `kcl_ok`. |
| `src/leakage/spice.py` | Model-card read/edit, ngspice discovery, ASCII raw-file parser (`parse_raw_ascii`). |
| `scripts/a1_smoke_test.py` | Four-case nominal smoke test plus a 192-point corner sweep. Also writes the example netlists. |
| `netlists/transistor/*.cir` | Stand-alone example netlist for each case (deliverable 2). |

### How a simulation runs
1. Each sample becomes a self-contained circuit containing:
   - the required `.options` line;
   - `.temp`;
   - one FET with `L = 45 nm`;
   - a separate voltage source on each of d, g, s and b;
   - a copy of that device's own `.model` card from `45nm_HP.pm`, with the sample's vth0/toxe/ndep/u0/xj written in.

   The other device's card is left out, and the supplied `.pm` file is only ever read (a test checks its SHA-256).
2. About 200 circuits share one ngspice process. A driver runs `source s<k>.cir` → `op` →
   `write o<k>.raw i(vd) i(vg) i(vs) i(vb)` for each one, and up to 11 processes run in parallel.
3. Values come from ngspice's **ASCII raw files** (structured, full double precision), never from the printed log.
4. A circuit that fails writes no raw file. It is marked `failed` and re-run on its own to collect
   its exact error messages. Other circuits are unaffected (tested with an unknown-model circuit and a singular-matrix circuit).
5. Results are identical (relative difference < 1e-9) to running each example netlist on its own (tested).

### Sign convention
Every current is **positive when it flows into the device terminal**: `I_X = -i(VX)`.
At the nominal NMOS ON point, `i(vd) = -1.1208e-04`, so Id = +1.1208e-04 A, flowing into the drain.

### Kirchhoff check
The pass criterion is |Id + Ig + Is + Ib| ≤ 1e-6·max|I| + 10 fA.

At the nominal points the residual is 1e-17 A or less. When every current is tiny (≤ 1e-12 A, e.g. Vd = Vs), ngspice's BSIM4 code leaves a fixed residual of about 1.2 fA. That figure did not change with gmin, reltol or vntol (measured), so it comes from the device model, not from solver tolerances.

### How this differs from the supplied `22n_NMOS_ON.net`
That file was used for reference only. Its Linux `.include` path, `GMIN=1e-20` options, 22 nm sizes, Vg-referenced-to-`Ref` VDD sweep and `dc TEMP` sweep were all replaced:
- every sample gets one `op`;
- VDD, T, W, Vd, Vs and the process parameters are independent inputs;
- the required options line is used;
- the model card is embedded, so the netlist contains no paths.

### Reproduce
```powershell
.\.venv\Scripts\python.exe -m pytest -q tests
.\.venv\Scripts\python.exe scripts\a1_smoke_test.py
& $env:NGSPICE -b netlists\transistor\nmos_on.cir      # NGSPICE = full path of ngspice_con.exe
```
The smoke-test results go to `results/a1_smoke_test.csv`, `results/a1_corner_sweep.csv` and `reports/a1_smoke_test.md`.

### API example
```python
from leakage.config import load_config
from leakage.transistor import simulate_transistor, sample_inputs, simulate_transistors
cfg = load_config()
r  = simulate_transistor(cfg, "nmos_off", vdd=0.95, temp=85, w=180e-9, vd=0.95, vs=0.0,
                         process={"vth0": 0.45, "toxe": 1.2e-9})
df = simulate_transistors(cfg, "pmos_on", sample_inputs(cfg, "pmos_on", 100))
```

## Part A1: dataset generation

Script: `scripts/a1_generate_datasets.py`; logic in `src/leakage/dataset.py`.

```powershell
# 20-sample smoke test per case (run after any code change)
.\.venv\Scripts\python.exe scripts\a1_generate_datasets.py --smoke
# quick end-to-end run: 200 samples per case into data\transistor_small\
.\.venv\Scripts\python.exe scripts\a1_generate_datasets.py --small
# full run: 10,000 valid samples per case into data\transistor\ (smoke test runs first)
.\.venv\Scripts\python.exe scripts\a1_generate_datasets.py
```
Other options: `--cases nmos_off pmos_off`, `--n 2000`, `--out data\tmp`, `--batch 500`,
`--workers 6`, `--max-extra 200`, `--skip-smoke`, `--no-progress`.

**Sampling** (spec Section 4):
- VDD ~ U(0.9, 1.1) V, drawn first.
- T ~ U(−40, 125) °C.
- W ~ U(45, 360) nm.
- Vd and Vs: each drawn independently from U(0, VDD).
- vth0/toxe/ndep/u0/xj: each drawn independently from U(±10 %) around that device's own nominal value.
- Vg and Vb are set by the case.

**Reproducibility and stable IDs:**
- Sample *k* of a case is drawn from `default_rng([case_seed, k // 1000])`, and every block of 1000 is always drawn in full.
- So sample *k* gets identical inputs whatever `--n` is, and the small run is an exact prefix of the full run.
- Per-case seeds are `seeds.data + 100·case_index` (1001, 1101, 1201, 1301).
- Inputs are rounded to the 12 significant digits written into the netlist, so the CSV holds exactly what was simulated.

**Robustness:**
- Each batch (`--batch`, default 1000) is saved once, atomically, to `data/transistor/_shards/<case>/`.
- Rerunning the same command resumes: saved IDs are skipped, so nothing is duplicated (tested by deleting shards). Ctrl+C is safe.
- Failed simulations keep NaN currents, never zeros. They are listed in `failures.csv`, and the next unused IDs are simulated until there are N valid samples. The run stops if more than `--max-extra` replacements would be needed.
- Parallelism is a fixed pool of `--workers` ngspice processes, 11 by default.

**Outputs** in `data/transistor/`:

| File | Content |
|---|---|
| `<case>.csv` | the dataset: columns `vdd, temp, w, vd, vs, vg, vb, vth0, toxe, ndep, u0, xj, id, ig, is, ib`, sorted by sample ID |
| `<case>_index.csv` | maps each row to its sample ID, plus that row's Kirchhoff sum |
| `failures.csv` | each failed simulation with its inputs and simulator messages |
| `metadata.json` | seeds, ranges, versions, git commit, model hash, timings, validation results, current statistics |
| `summary.md` | per-case counts and checks (also copied to `reports/a1_dataset_summary.md`) |

**Validation** runs on every final CSV and checks:
- the row count, column order and that every value is finite;
- every input range, and the Vg/Vb case rule;
- each process parameter is within ±10 % of the correct device's nominal;
- input rows and sample IDs are unique, and no current is exactly zero;
- Kirchhoff's law holds for every row.

## Part A1: data check (deliverable 3)

```powershell
.\.venv\Scripts\python.exe scripts\a1_data_check.py
```
This takes about 2 minutes. It reads `data/transistor/` and writes everything to `results/data_check/`:

| File | Content |
|---|---|
| `data_quality_report.md` | written report (also copied to `reports/a1_data_quality_report.md`) |
| `kcl_summary.csv` | Id+Ig+Is+Ib for each case: max / median / p95, absolute and relative |
| `quality_checks.csv` | range, missing-value, uniqueness and failure checks |
| `fig_off_current_vs_temperature.png`, `fig_off_current_vs_vth0.png`, `fig_gate_current_vs_toxe.png` | the three required trend plots (NMOS and PMOS panels) |
| `fig_supp_off_current_vs_source_offset.png`, `source_offset_effect.csv` | why the OFF-current plots condition on the source potential |
| `trend_slopes.csv` | slopes with the other inputs held fixed vs controlled SPICE sweeps |
| `controlled_sweeps.csv` | reference SPICE sweeps varying one input at a time (not training data) |
| `suspicious_samples.csv` | flagged samples with the reason (nothing is removed) |
| `warning_audit.csv` | flagged plus random samples re-simulated alone: exact messages and a reproduction check |

**Key findings:**
- **Kirchhoff:** 0 of 40,000 samples exceed the tolerance; the largest absolute residual is about 2e-15 A.
- **Trends:** all three have the expected sign, and their slopes match the controlled sweeps (for example, NMOS Ig vs toxe: −0.66 vs −0.65 decades per 0.1 nm).
- **Conditioning:** the OFF-current plots must condition on the source potential, not just |Vds|. Each 0.1·VDD that the source sits off its rail cuts the current by about 1 decade.
- **toxe warning:** every sample with a non-nominal toxe triggers the BSIM4 warning "toxe != toxp + dtox; dtox ignored", because the spec varies toxe only. It is documented as a modelling assumption.

## Part A2: ML transistor models

### Commands
```powershell
# train + tune + select + save (about 1.5 h on 12 cores; resumable, results cached in results\a2\tuning\)
.\.venv\Scripts\python.exe scripts\a2_train_models.py
# quick code check with a tiny grid (about 2 min; writes results\a2_quick, saves no models)
.\.venv\Scripts\python.exe scripts\a2_train_models.py --quick
# ONE-TIME test-set evaluation (refuses to run twice)
.\.venv\Scripts\python.exe scripts\a2_evaluate_test.py
# reload the saved models and predict one transistor (add --spice to compare with ngspice)
.\.venv\Scripts\python.exe scripts\a2_predict.py --device nmos --vd 1.0 --vg 0 --vs 0 --vb 0 --vdd 1.0 --temp 27 --w 90e-9 --spice
```
From Python:
```python
import sys; sys.path.insert(0, "src")
from leakage.inference import LeakagePredictor
lp = LeakagePredictor()                                   # loads trained_models\<case>.joblib
lp.predict("pmos", vd=0.0, vg=1.0, vs=1.0, vb=1.0, vdd=1.0, temp=85, w=180e-9, vth0=-0.47)
# -> DataFrame: case, id, ig, is, ib (A, positive into the device), extrapolated
```
The ON/OFF state is inferred from Vg (NMOS is ON when Vg = VDD; PMOS is ON when Vg = 0), or you can pass `state=`.
- Vg and Vb must follow the case rule.
- Process parameters default to nominal.
- Inputs outside the training ranges are flagged (`strict=True` raises an error instead).

### Results (test set, evaluated once; full report in `reports/a2_ml_report.md`)
An MLP was selected in all four cases. Mean over Id/Ig/Is/Ib:

| Case | Median rel. err | p95 rel. err | R²_t |
|---|---|---|---|
| NMOS ON | 2.43 % | 13.2 % | 0.9989 |
| NMOS OFF | 1.54 % | 9.6 % | 0.9990 |
| PMOS ON | 2.75 % | 18.6 % | 0.9975 |
| PMOS OFF | 1.14 % | 7.3 % | 0.9976 |

- **Ig and Ib:** median error 0.6–1.3 %, with signs 100 % correct.
- **Id and Is** carry most of the error, worst for ON devices at |Vds| < 0.05 V.
- **99 % target:** not reached as a mean over terminals (best: 98.9 % for PMOS OFF). It is reached by Ig and Ib in the OFF cases.

Plots: `results/a2/fig_pred_vs_spice_<case>.png`. Validation table: `results/a2/validation_comparison.csv`.

### Method
- **Split:** 70/15/15 per case with a fixed seed, saved in `data/transistor/splits.csv`.
  - Test rows are dropped before any fitting.
  - Scalers and target statistics use the training split only.
  - Tuning and model selection use validation only.
  - The test set is evaluated once by a separate script that keeps a record.
- **Features** (`src/leakage/ml.py`): VDD, T in K, log10 W, Vd, Vs, Vds, |Vds|, Vgs, Vgd, Vbs, Vbd, the source offset from its rail, and each process parameter relative to its nominal value.
- **Targets:** all four terminal currents together (multi-output), transformed with `asinh(I/1e-15 A)`. This works like a signed log, keeps the sign and passes smoothly through zero. It was chosen by a validation study (`results/a2/transform_study.csv`):
  - linear targets did far worse;
  - asinh with I₀ = 1e-18, 1e-12 or 1e-9 A did worse;
  - sign classifier + log10|I| did slightly better, but it needs a second model per terminal.
- **Algorithms:** polynomial ridge, random forest, LightGBM and an MLP (L-BFGS, tanh), each grid-searched on validation.
- **Selection:** the lowest mean over Id/Ig/Is/Ib of the validation median relative error.
- **Reproducibility:** every fit uses fixed seeds and exactly 2 BLAS threads, because the thread count changes MLP results. Each saved model stores its metadata (split and dataset hashes, hyperparameters, validation metrics, versions).
- **Error definitions:**
  - Relative error is |I_pred − I_spice| / max(|I_spice|, 1 fA).
  - Absolute error is in A.
  - Scale error is the error divided by the sample's largest terminal current.
  - Sign accuracy counts only samples with |I| ≥ 10 fA.
  - R²_t is R² of asinh(I/1 fA).

## Part B step 3: gate-level SPICE references

```powershell
.\.venv\Scripts\python.exe scripts\b3_gate_spice.py --smoke   # nominal corner + corner 0, 36 sims, ~10 s
.\.venv\Scripts\python.exe scripts\b3_gate_spice.py           # smoke first, then 18 x 200 = 3,600 sims (~5-12 min)
& $env:NGSPICE -b netlists\gates\NAND2.cir
```
- **Gates** (`src/leakage/gates.py`; topologies are stored as data so Part B step 4 and Part C can reuse them):
  - INV, NAND2, NOR2, and AND2/OR2, which are NAND2/NOR2 followed by an inverter and simulated as one netlist.
  - Bodies connect NMOS→0 and PMOS→VDD.
- **Sizing:** the PDF doesn't specify it, so equal-drive sizing is used. The unit inverter has Wn = 90 nm and Wp = 180 nm; series pairs use 2× unit width.
  - INV: N 90 / P 180 nm.
  - NAND2: N 180 (series) / P 180 nm.
  - NOR2: N 90 / P 360 nm (series).
  - Every width lies within the ML training range of 45–360 nm.
- **Corners:** 200 corners in `data/gates/corners.csv`. Each corner has its own RNG, `default_rng([4004, corner_id])`, which draws VDD, T, one NMOS draw of the 5 process parameters and one separate PMOS draw. The same `corner_id`s are used for every gate and will be reused in Part C.
- **Inputs:** exactly 0 or the sampled VDD. Every netlist carries the required `.options` line, and every transistor terminal has a 0 V current probe.
- **Leakage:** `I_leak = Σ_k V_k·(−i(V_k)) / VDD` over the VDD rail and input sources, i.e. static power divided by VDD. It is always positive and includes gate tunnelling drawn from inputs held at VDD. The VDD-rail current alone is stored as `i_vdd`.
- **Outputs:**
  - `data/gates/gate_spice_results.csv`: 3,600 rows with leakage, v(out), x/y/n1 node voltages and checks.
  - `data/gates/gate_spice_devices.csv`: terminal voltages and SPICE currents of every transistor.
  - `failures.csv` and `metadata.json` in the same folder.
  - `results/b3/` (truth table, per-case summary, report).
- **Checks:**
  - 3,600/3,600 converged and 3,600/3,600 truth tables correct.
  - The power from the sources matches Σ V·I over all device terminals to within 1e-6 relative (`reltol`).
- These results are evaluation references only. No model is trained on them.

## Part B steps 4–5: hierarchical ML gate leakage

```powershell
.\.venv\Scripts\python.exe scripts\b4_gate_ml.py      # ~5 s; no SPICE is run
```
Reuse it, for example in Part C:
```python
from leakage.gate_ml import GateLeakageModel
gm = GateLeakageModel()                   # final transistor models + Part B node voltages
gm.leakage("NAND2", "01", [0, 1, 2])      # predicted I_leak (A) at corners 0..2
```
**Method** (`src/leakage/gate_ml.py`):
- **No gate-level model is trained.** Each transistor's Vd/Vg/Vs/Vb comes from its circuit connections: inputs exactly 0/VDD, bodies on the rails.
- **Internal and output node voltages (out, x, y, n1) are the SPICE-recorded values from step 3**, as the PDF allows. The predictions are therefore *not* independent of SPICE node voltages.
- **ON/OFF model choice:** by gate bias. Gates driven by n1 (the AND2/OR2 inverter) are snapped to the nearest rail; the largest snap is 0.3 mV, and it is recorded.
- **Leakage:** `I_leak = Σ[(Vd−Vs)Id + (Vg−Vs)Ig + (Vb−Vs)Ib] / VDD`, which equals the SPICE definition by Tellegen's theorem.
  - KCL is enforced per device, and each terminal is counted once.
  - Verified by feeding SPICE's own transistor currents through the same code: all 3,600 cases reproduce the SPICE leakage.
- **No hidden SPICE:** inference runs with subprocess execution blocked, with 0 calls attempted (3,600 cases in 0.2 s).

**Results** (`results/b4/`, `reports/b4_gate_ml_report.md`), over 3,600 predictions:

These results use the models of that stage (v2 in all four cases; the final v3 results are in the table at the top):

| Metric | Value |
|---|---|
| Median error | 3.4 % |
| 95th-percentile error | 12.8 % |
| Bias | −0.6 % |
| Mean accuracy | 95.4 % (99 % target not met) |

- **Best:** NAND2 00 (2.4 %) and AND2 00 (2.8 %).
- **Worst:** NOR2 10 (5.8 %) and NOR2 01 (4.0 %).
- **Error source:** OFF transistors at rail biases still dominate the gate error.
- **Earlier run, kept for disclosure:** with v1 OFF models the results were median 4.4 %, p95 21.6 %, mean accuracy 93.1 %. They are archived in `results/b4_archive_off_v1/`, and `reports/a2b_improvement_report.md` explains the switch.
- Full 18-case table: `results/b4/gate_accuracy_18cases.csv`. Parity plot: `results/b4/fig_gate_parity.png`.

## Part C: 3-bit carry-lookahead adder (assigned test circuit)

```powershell
.\.venv\Scripts\python.exe -m pytest -q tests\test_circuit.py      # exhaustive Boolean tests (Cin = 0 and 1)
.\.venv\Scripts\python.exe scripts\c1_cla_spice.py --smoke         # 128 full-circuit sims (~10 s)
.\.venv\Scripts\python.exe scripts\c1_cla_spice.py                 # smoke + 64 x 200 = 12,800 sims (~16 min)
.\.venv\Scripts\python.exe scripts\c2_cla_ml.py                    # hierarchical ML + evaluation (~30 s)
```
**Circuit** (`src/leakage/circuit.py`, gate list in `data/circuit/cla3_gate_list.csv`, netlist in `netlists/circuit/CLA3.cir`):
- **Logic:** Gi = Ai·Bi, Pi = Ai⊕Bi, C1 = G0 + P0·C0, C2 = G1 + P1·G0 + P1·P0·C0, C3 = G2 + P2·G1 + P2·P1·G0 + P2·P1·P0·C0, Si = Pi⊕Ci.
- **Lookahead:** no carry is computed from another carry (tested).
- **XOR:** built as AND2(OR2, NAND2), with NAND2(Ai, Bi) shared with Gi = INV(·).
- **Size:** 36 gates (15 AND2, 12 OR2, 6 NAND2, 3 INV) and 192 transistors. Widths, bodies, model cards and process draws are the same as Part B.
- **Carry-in:** tied to logic 0, which gives 64 operand vectors. The Boolean model is verified for all 128 combinations (Cin = 0 and 1).

**SPICE reference** (`data/circuit/cla3_spice_results.csv`): the complete 192-transistor netlist at the 200 Part B corners.
- All 12,800 runs converged, and the outputs equal A+B in every one.
- Every internal net is within 0.03 % of VDD of its logic level.
- Leakage uses the same definition as Part B.

**Hierarchical ML** (`data/circuit/cla3_ml_predictions.csv`):
- Boolean simulation gives each gate's inputs, and the Part B gate model gives each gate's leakage. The circuit leakage is the sum over the 36 gates.
- Gate-internal voltages are looked up from the Part B *isolated-gate* SPICE runs. Nothing from the full-circuit SPICE run is used.

| 12,800 cases | Median err | p95 err | Bias | Mean accuracy | R² (log10) |
|---|---|---|---|---|---|
| ML vs full-circuit SPICE | 2.65 % | 10.6 % | −0.8 % | 96.3 % | 0.998 |
| Σ Part B SPICE gates vs full circuit (composition only) | 0.006 % | 0.04 % | −0.006 % | 99.99 % | 1.000 |

Loading turned out negligible here. Nearly all of the error comes from the ML models, and it is *lower* than at gate level because the 36 per-gate errors partly cancel. What remains is a corner-level bias that depends on temperature. Full report: `reports/c_cla3_report.md`; plot: `results/c/fig_cla3_parity.png`.

## Improvement phase (accuracy and reliability)

Full report: `reports/improvement_report.md`. The protocol (`results/improve/selection_rule.md`) was fixed before any experiment ran:
- every decision used **validation only**;
- before and after were scored **once** on new, untouched data (fresh transistor tests, plus 200 new corners with seed 5005 and their own gate and CLA SPICE references);
- original result files and models are preserved. The previous finals are in `trained_models/final_before_improvement/`; Parts B4/C results remain in `results/b4`, `results/c`.

```powershell
.\.venv\Scripts\python.exe scripts\d1_diagnostics.py                       # error analysis (train/val)
.\.venv\Scripts\python.exe scripts\d2_experiments.py --exp E1_ens_v2cache E2_torch_same E5_torch_moredata E6_ens_E2_E5
.\.venv\Scripts\python.exe scripts\d2_experiments.py --select --summary    # -> trained_models\v3
.\.venv\Scripts\python.exe scripts\d5_op_uniqueness.py --gates data\final_eval\gates data\gates
.\.venv\Scripts\python.exe scripts\d3_final_eval.py [--refs corrected]     # one-time before/after
.\.venv\Scripts\python.exe scripts\d4_report.py
```
**What limited accuracy:**
- Every earlier MLP stopped at sklearn's 3,000-iteration L-BFGS cap; training error ≈ validation error, so the models were under-fitted.
- **Fix:** the same network trained with PyTorch L-BFGS (`src/leakage/torch_mlp.py`, numpy inference) for 15–20k iterations. On validation, median error fell about 4×.
- After that, the near-rail validation error was 2–18× the training error. So a modest batch of extra targeted transistor samples was added (salt 6).
- An ensemble was selected for NMOS ON.

**Before → after on the new independent data:**

| Level | Median err | p95 err | Mean accuracy |
|---|---|---|---|
| Transistor (spec distribution) | 2.77 % → 0.61 % | 12.0 % → 3.4 % | 95.5 % → 98.6 % |
| Gates (18 × 200, new corners) | 3.80 % → 0.78 % | 13.7 % → 3.0 % | 95.1 % → 98.9 % |
| **3-bit CLA (64 × 200, new corners)** | 2.98 % → 0.57 % | 10.1 % → 2.3 % | 96.3 % → **99.24 %** |

**99 % target:** reached at circuit level; **not** reached at gate level (98.9 %) or transistor level (98.6 %).

**SPICE reference integrity:** one new-corner gate record had a spurious operating point.
- ngspice's default solve converged to a non-physical internal body-node state, which `d5_op_uniqueness.py` detects using SPICE only.
- It was corrected in a separate file. All other 7,199 gate and 25,600 CLA references are unique.
- The simulator also now retries isolated non-converging circuits with raised DC iteration limits; this was needed once.

Final transistor models: `trained_models/<case>.joblib` (= `trained_models/v3/`). NMOS ON is an ensemble of two PyTorch MLPs; the other three are single PyTorch MLPs trained with the extra data.

## Workflow status

| Stage | Status |
|---|---|
| 0. Setup, inventory, environment check | done |
| A1. Simulation engine, example netlists, 4 × 10,000 datasets, data check | done |
| A2. 4 model types × 4 cases, selection, one-time test, inference API | done |
| A2b. v2 models (signed-log Vds feature, targeted data), one-time fresh test, disclosed OFF amendment | done |
| B3. Gate SPICE references (18 cases × 200 corners) | done |
| B4–5. Hierarchical ML gate leakage | done |
| C. 3-bit CLA SPICE references + hierarchical ML | done |
| Improvement phase (v3 models, independent final evaluation, SPICE operating-point check) | done |
| Final deliverables, technical report, audit, master runner | done |
